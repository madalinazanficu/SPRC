
from flask import Flask, jsonify

import os
import pymongo

from mongoengine import connect
from bson import ObjectId

app = Flask(__name__)

client = pymongo.MongoClient('mongo_db', 27017)
db = client['database']

@app.route('/')
def hello_world():
    
    try:
        db = client['database']
        db.authenticate('admin', 'admin')
        return 'Connected successfully!'
    except:
        return 'Could not connect to MongoDB'
    
    id = 0
    nume = 'Romania'
    lat = '45.9432'
    long = '24.9668'
    
    db.tari.insert_one({'_id': id, 'nume_tara': nume, 'latitudine': lat, 'longitudine': long})
    return nume

if __name__ == '__main__':
    app.run('0.0.0.0', port=6000, debug=True)
