import os
from flask import Flask

# import pymongo
# from pymongo import MongoClient
from db_entities import Tari, Orase, Temperaturi


app = Flask(__name__)


# app.config['MONGO_URI'] = 'mongodb://' + \
#                         os.environ['MONGODB_USERNAME'] + \
#                         ':' + os.environ['MONGODB_PASSWORD'] + '@' + \
#                         os.environ['MONFODB_HOSTNAME'] + \
#                         ':27017/mongo?authSource=admin&retryWrites=true&w=majority' 

# mongoClient = pymongo.MongoClient(app.config['MONGO_URI'])
# db = mongoClient["database"]

# # Connect to MongoDB
# app.config['MONGO_URI'] = 'mongodb://localhost:27017/MyDatabase'

# # Check the connection to MongoDB
# mongoClient = MongoClient(app.config['MONGO_URI'])

# # Create the database which contains Tari, Orase and Temperaturi collections
# db = mongoClient["database"]


@app.route('/')
def hello_world():
    tara = Tari(id=1, nume_tara='Romania', latitudine=45.9432, longitudine=24.9668)
    
    # db.tari.insert_one(tara.to_mongo())
    
    # print(db.tari.find_one({'id': 1}))
    # return db.tari.find_one({'id': 1})['nume_tara']
    return tara


if __name__ == '__main__':
    app.run('0.0.0.0', port = 6000, debug = True)