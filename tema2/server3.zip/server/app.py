from flask import Flask
import pymongo

app = Flask(__name__)

# client = pymongo.MongoClient('mongo_db', 27017)

#Autentificare la baza de date
# client = pymongo.MongoClient('mongo_db', 27017, username='root', password='root')
client = pymongo.MongoClient("mongodb://root:root@mongo_db:27017/")
db = client['database']

@app.route('/')
def hello_world():
    try:
        # Verificare conexiune
        client.server_info()
        
        # Inserare date
        db.tari.insert_one({'nume': 'Romania', 'capitala': 'Bucuresti'})
        
        return 'Connected successfully and data inserted!'
    
    except pymongo.errors.ServerSelectionTimeoutError:
        return 'Could not connect to MongoDB'

if __name__ == '__main__':
    app.run('0.0.0.0', port=6000, debug=True)
