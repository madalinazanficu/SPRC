from flask import Flask
from pymongo import MongoClient
from mongoengine import connect
from db_entities import Tari

def connect_to_database():
    try:
        client = MongoClient(host = 'mongo',
                             port = 27017,
                             username = 'admin',
                             password = 'admin',
                             authSource = 'admin')
    
        db = client['mongo']
        
        connect(
            db = 'mongo',
            host = 'mongo',
            username = 'admin',
            password = 'admin',
            authentication_source = 'admin'
        )
        
        print("Connected to database!")
        return db
    except:
        print("Error connecting to database!")
        return None

# ------------- Definire aplicatie Flask
app = Flask(__name__)



# ------------ Autentificare la baza de date
database_connection = connect_to_database()
if database_connection is None:
    print("Exiting...")
    exit(1)
else:
    print("Connected to database!")
    
    

# ------------- Definire rute
@app.route('/')
def hello_world():
    
    tara = Tari(id = 1, nume_tara = "Romania", latitudine = 45.9432, longitudine = 24.9668)
    try:
        tara.save()
        return "Inserted into database!"
    
    except:
        return "Error inserting into database!"
    
    # try:
    #     database_connection['test_collection'].insert_one({"name": "test"})
    #     return "Inserted into database!"
    # except:
    #     return "Error inserting into database!"

if __name__ == '__main__':
    app.run('0.0.0.0', port=6000, debug=True)
