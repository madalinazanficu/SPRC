from flask import Flask
import mysql.connector

def connect_to_database():
    try:
        connection = mysql.connector.connect(
            host = 'mysql',
            user = 'admin',
            password = 'admin',
            database = 'database'
        )
        return connection
    
    except mysql.connector.Error as err:
        print("Something went wrong: {}".format(err))
        return None

app = Flask(__name__)

# ------------ Autentificare la baza de date
database_connection = connect_to_database()
if database_connection is None:
    print("Exiting...")
    exit(1)
else:
    print("Connected to database!")


# ------------ Creare tabele
def create_users_table():
    create_table_query = """
        CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT,
            username TEXT,
            password TEXT,
            PRIMARY KEY (id)
        )
    """
    try:
        cursor = database_connection.cursor()
        cursor.execute(create_table_query)
        print("Table created successfully!")
        
    except mysql.connector.Error as err:
        print("Something went wrong: {}".format(err))
    
    finally:
        cursor.close()
        
        
create_users_table()
    
# ------------- Definire rute
@app.route('/')
def hello_world():
    
    insert_query = "INSERT INTO users (username, password) VALUES (%s, %s)"
    user_data = ("username", "password")
    
    cursor = database_connection.cursor()
    
    try:
        cursor.execute(insert_query, user_data)
        database_connection.commit()
        return "User inserted!"
    except mysql.connector.Error as err:
        return "Something went wrong: {}".format(err)
    finally:
        cursor.close()



if __name__ == '__main__':
    app.run('0.0.0.0', port=6000, debug=True)
